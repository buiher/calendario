-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 09-03-2019 a las 21:10:53
-- Versión del servidor: 5.0.51
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `agenda`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `evento`
-- 

CREATE TABLE `evento` (
  `id_evento` int(11) NOT NULL auto_increment,
  `id_usuario` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `fecha_inicial` date NOT NULL,
  `hora_inicial` time default NULL,
  `fecha_final` date default NULL,
  `hora_final` time default NULL,
  `evento_dia` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id_evento`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `evento`
-- 

INSERT INTO `evento` VALUES (1, 1, 'lo que sea', '2019-03-04', '08:00:00', '2019-03-06', '23:00:00', 0);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuario`
-- 

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL auto_increment,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nombre_completo` varchar(255) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  PRIMARY KEY  (`id_usuario`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- Volcar la base de datos para la tabla `usuario`
-- 

INSERT INTO `usuario` VALUES (1, 'buiher@hotmail.com', 'b7a16940d4a39231658b6f59d500f4ad', 'Rafael Buitrago', '1980-08-08');
INSERT INTO `usuario` VALUES (2, 'admin@admin.com', '202cb962ac59075b964b07152d234b70', 'Pedro Perez', '1980-08-08');
INSERT INTO `usuario` VALUES (4, 'admin2@admin.com', '81dc9bdb52d04dc20036dbd8313ed055', 'Hugo Perez', '1980-08-08');
INSERT INTO `usuario` VALUES (5, 'admin3@admin.com', '827ccb0eea8a706c4c34a16891f84e7b', 'Paco Perez', '1980-08-08');
